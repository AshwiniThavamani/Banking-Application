package com.wallet.db;

import java.util.HashMap;

import com.wallet.bean.Customer;

public class WalletDB {

	
	
private static HashMap<Long, Customer> customerMap=new HashMap<Long, Customer>();

 static {
	 customerMap.put((long) 1458758, new Customer("Ashwini","Female","21","ashwini@gmail.com","8978675678",(long)1458758,67000));
	 customerMap.put((long) 1458759, new Customer("Gayathri","Female","22","gayathri@gmail.com","7863675678",(long)1458759,67000));
	 customerMap.put((long) 1458760, new Customer("Divya","Female","23","divyak@gmail.com","9990675678",(long)1458760,67000));
	
 }

public static HashMap<Long, Customer> getCustomerMap() {
	// TODO Auto-generated method stub
	return customerMap;
}
	
}
