package com.wallet;
import com.wallet.bean.Customer;
import com.wallet.dao.IWalletDao;
import com.wallet.dao.WalletDao;
import com.wallet.exception.WalletException;
import junit.framework.TestCase;


public class ClientTest extends TestCase
{
	
	IWalletDao dao=new WalletDao();
	public void init() {
		
	}
    
	public final void testCreateCustomer()
	{
		Customer cus=new Customer();
		cus.setAccountNo(1234);
		cus.setAge("23");
		cus.setBalance(1000);
		cus.setEmail("ash@gmail.com");
		cus.setGender("Female");
		cus.setMobile("6767674534");
		cus.setName("Ash");
		try {
			dao.addCustomer(cus);
			double e=dao.ShowBalance(1234);
			assertNotNull(e);
		} catch (WalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void testShowBalance()
	{
	try
	{
		double e=dao.ShowBalance(1234);
		assertNotNull(e);
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}
	
	public void testcheckAccountNo()
	{
		try
		{
			boolean e=dao.checkAccountNo(1234);
			assertNotNull(e);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void testdeposit()
	{
		try
		{
			double e=dao.deposit(100, 1234);
			assertNotNull(e);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void testwithdraw()
	{
		try
		{
			double e=dao.withdraw(100, 1234);
			assertNotNull(e);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
  
}
