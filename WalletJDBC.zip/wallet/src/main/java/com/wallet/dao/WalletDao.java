package com.wallet.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.wallet.bean.Customer;

import com.wallet.exception.WalletException;
import com.wallet.util.DBConnection;




public class WalletDao implements IWalletDao{
	
	Logger logger=Logger.getRootLogger();
    
	 public WalletDao() {
		 PropertyConfigurator.configure("resources//log4j.properties");
	}

	@SuppressWarnings("resource")
	@Override
	public long addCustomer(Customer customer) throws WalletException {
		// TODO Auto-generated method stub
		
		
        Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		int accountId=0;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1, customer.getName());
			preparedStatement.setString(2, customer.getGender());
			preparedStatement.setString(3, customer.getAge());
			preparedStatement.setString(4, customer.getEmail());
			preparedStatement.setString(5, customer.getMobile());
			preparedStatement.setDouble(6, customer.getBalance());		
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.ACCOUNTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				accountId=resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("Inserting customer details failed ");

			}
			else
			{
				logger.info("Customer details added successfully:");
				return accountId;
			}
		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
	}
	
	
	@Override
	public double ShowBalance(long accountNo) throws WalletException {
		// TODO Auto-generated method stub
		
        Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.SHOW_BALANCE);
			preparedStatement.setLong(1,accountNo);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
		    double rs= resultSet.getDouble("balance");
		    return rs; 
		    }
			else {
				System.out.println("Account doesnot exist..");
			}
			 return 0;
		   
	    }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Tehnical problem occured refer log ");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
	}

	@SuppressWarnings("resource")
	@Override
	public double deposit(double bal, long getAccountNo) throws WalletException {
		// TODO Auto-generated method stub
		
		
        Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		double rs=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.DEPOSIT_BALANCE);
			preparedStatement.setDouble(1, bal);
			preparedStatement.setLong(2,getAccountNo);
			int queryResult = preparedStatement.executeUpdate();
			
			preparedStatement = connection.prepareStatement(QueryMapper.SHOW_BALANCE);
			preparedStatement.setLong(1,getAccountNo);
			resultSet=preparedStatement.executeQuery();

			
		    resultSet.next();
			
		    rs= resultSet.getDouble("balance");
		   
			if(queryResult==0)
			{
				logger.error("Deposit failed ");
				throw new WalletException("Account Number doesnot Exist ");

			}
			else
			{
				logger.info("Added amount in your account successfully...");
				 return rs; 
			}
			
			 
		   
	    }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log ");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
	}

	@SuppressWarnings("resource")
	@Override
	public double withdraw(double bal, long accountNo) throws WalletException {
		// TODO Auto-generated method stub
		
		
		  Connection connection = DBConnection.getInstance().getConnection();	
			
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			double rs=0;
			try
			{		
				preparedStatement=connection.prepareStatement(QueryMapper.WITHDRAW_BALANCE);
				preparedStatement.setDouble(1, bal);
				preparedStatement.setLong(2,accountNo);
				int queryResult = preparedStatement.executeUpdate();
				
				preparedStatement = connection.prepareStatement(QueryMapper.SHOW_BALANCE);
				preparedStatement.setLong(1,accountNo);
				resultSet=preparedStatement.executeQuery();

				
			    resultSet.next();
				
			    rs= resultSet.getDouble("balance");
			   
				if(queryResult==0)
				{
					logger.error("Withdraw failed ");
					throw new WalletException("Account Number doesnot Exist ");

				}
				else
				{
					logger.info("Amount in your account withdrawn successfully...");
					 return rs; 
				}
		   }
			catch(SQLException sqlException)
			{
				logger.error(sqlException.getMessage());
				sqlException.printStackTrace();
				throw new WalletException("Tehnical problem occured refer log ");
			}
			finally
			{
				try 
				{
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					logger.error(sqlException.getMessage());
					throw new WalletException("Error in closing db connection");	
				}
			}
			
	}

	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 

	/*static HashMap<Long, Customer> customerMap=WalletDB.getCustomerMap();
	

	public long addCustomer( Customer customer) throws WalletException {
		// TODO Auto-generated method stub
		try {
			Optional<Long>id=customerMap.keySet().stream().max(new Comparator<Long>() {
				@Override
				public int compare(Long x, Long y) {
					return x>y?1:x<y?-1:0;
				}
			});
				long reqId=id.get()+1;
				customer.setAccountNo(reqId);
			
			customerMap.put(customer.getAccountNo(), customer);
			return customer.getAccountNo();
		}
		catch(Exception ex) {
			throw new WalletException(ex.getMessage());
		}
		
		
	}


	@Override
	public boolean checkAccountNo(long accountNo) throws WalletException {
		// TODO Auto-generated method stub
		
		try {
			Customer customer=customerMap.get(accountNo);
			if(customer==null) {
				throw new WalletException("Customer with account no  "+accountNo+"  not available in the database");
			}
			return true;
			}
	     	catch(Exception ex)
			
			{
			throw new WalletException(ex.getMessage());
			}
	}


	@Override
	public double ShowBalance(long accountNo) throws WalletException {
		// TODO Auto-generated method stub
		try {
		Customer customer=customerMap.get(accountNo);
		return customer.getBalance();}
     	catch(Exception ex)
		
		{
		throw new WalletException(ex.getMessage());
		}

		
	}


	@Override
	public double deposit(double bal,long getAccountNo) throws WalletException {
		// TODO Auto-generated method stub
		Customer customer=customerMap.get(getAccountNo);
		double balance=customer.getBalance();
		customer.setBalance(bal+balance);
		return customer.getBalance();
	}


	@Override
	public double withdraw(double bal, long accountNo) throws WalletException {
		// TODO Auto-generated method stub
		Customer customer=customerMap.get(accountNo);
		double balance=customer.getBalance();
		customer.setBalance(balance-bal);
		return customer.getBalance();
	}
*/
}
