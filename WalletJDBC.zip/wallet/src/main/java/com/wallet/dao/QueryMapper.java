package com.wallet.dao;

public interface QueryMapper {

	String INSERT_QUERY = "INSERT INTO CustomerDetails VALUES(accountId_sequence.NEXTVAL,?,?,?,?,?,?)";
	
	String ACCOUNTID_QUERY_SEQUENCE = "SELECT accountId_sequence.CURRVAL FROM DUAL";
	String SHOW_BALANCE="SELECT balance from CustomerDetails where accountId=?";
	String DEPOSIT_BALANCE="UPDATE CustomerDetails set balance=balance+? where accountId=?";
	String WITHDRAW_BALANCE="UPDATE CustomerDetails set balance=balance - ? where accountId=?";
	String TINSERT_QUERY="Insert into transaction values(transactionId_sequence.NEXTVAL,?,?,?)";
	

}
