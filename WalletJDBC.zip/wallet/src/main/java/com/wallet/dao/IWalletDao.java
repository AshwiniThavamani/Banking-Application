package com.wallet.dao;


import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public interface IWalletDao {

	long addCustomer( Customer customer)throws WalletException;

	

	double ShowBalance(long accountNo)throws WalletException;

	double deposit(double bal,long getAccountNo)throws WalletException;

	double withdraw(double bal, long accountNo)throws WalletException;

}
