package com.wallet.service;

import com.wallet.bean.Customer;
import com.wallet.exception.WalletException;

public interface IWalletService {

	boolean validateCustomer(Customer customer)throws WalletException;

	long addCustomer(Customer customer)throws WalletException;

	double ShowBalance(long accountNo)throws WalletException;

	double desposit(double bal,long getAccountNo)throws WalletException;

	double withdraw(double bal, long accountNo)throws WalletException;
  
	
}
